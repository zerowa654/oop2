package login.application;

/**
 *
 * @author Muha
 */
public class Tocken {
    static String name;
    static String username;
    static Integer id;
}
